#include <stdio.h>
#include <thread>
#include <iostream>
#include <queue>
#include <stack>
#include <string>
using namespace std;

const int STACK_SIZE=3;

const int SLEEP_DURATION = 200;

int max;

int stacks[3][STACK_SIZE];

queue<string> solution1;

stack<string> solution2;

stack<string> solution;

void sleep() {
    this_thread::sleep_for(chrono::milliseconds(SLEEP_DURATION));
}

void repeatChar(char* str, int &start, int length, char c) {
    for (int i = start; i < start + length; i++) {
        str[i] = c;
    }
    start += length;
}

char* toBlockStr(int val) {
    char* out = new char[STACK_SIZE * 2 + 2];
    out[STACK_SIZE * 2 + 1] = 0;
    int next = 0;
    if (val == 0) {
        repeatChar(out, next, STACK_SIZE * 2 + 1, ' ');
        out[STACK_SIZE] = '|';
    }
    else {
        repeatChar(out, next, STACK_SIZE - val, ' ');
        out[next++] = '(';
        repeatChar(out, next, val - 1, '[');
        out[next++] = '|';
        repeatChar(out, next, val - 1, ']');
        out[next++] = ')';
        repeatChar(out, next, STACK_SIZE - val, ' ');
    }
    return out;
}

void show() {
    system("clear");
    for (int i = 0; i < 3; i++) {
        printf("%s", toBlockStr(0));
    }
    printf("\n");
    for (int y = STACK_SIZE - 1; y >= 0; y--) {
        for (int x = 0; x < 3; x++) {
            printf("%s", toBlockStr(stacks[x][y]));
        }
        printf("\n");
    }
//    sleep();
}

int topIndex(int stk) {
    for (int i = STACK_SIZE - 1; i >= 0; i--) {
        if (stacks[stk][i] != 0) {
            return i;
        }
    }
    return -1;
}

int top(int stk) {
    for (int i = STACK_SIZE - 1; i >= 0; i--) {
        if (stacks[stk][i] != 0) {
            return stacks[stk][i];
        }
    }
    return 0;
}

int pop(int stk) {
    for (int i = STACK_SIZE - 1; i >= 0; i--) {
        if (stacks[stk][i] != 0) {
            int ret = stacks[stk][i];
            stacks[stk][i] = 0;
            return ret;
        }
    }
    throw underflow_error("Stack empty, cannot pop any more.\n");
}

void push(int stk, int val) {
    for (int i = 0; i < STACK_SIZE; i++) {
        if (stacks[stk][i] == 0) {
            stacks[stk][i] = val;
            return;
        }
    }
    throw overflow_error("Stack full, cannot push any more.\n");
}

bool isEmpty(int peg) {
    return top(peg) == 0;
}

bool isValid(int src, int dst) {
    return isEmpty(dst) || top(src) < top(dst);
}

void moveBlock(int src, int dst) {
    show();
    if (isValid(src, dst)) {
        push(dst, pop(src));
    }
    else {
        throw invalid_argument("Can't put a bigger block over a smaller block");
    }
}

bool underBlock(int level, int peg) {
    return top(peg) < stacks[peg][level];
}

void moveStack(int y, int src, int dst, int tmp) {//level,source,destination,temporary
    if (underBlock(y, src)) {
        int tmpTop = topIndex(tmp);
        moveStack(y + 1, src, tmp, dst);
        moveBlock(src, dst);
        moveStack(tmpTop + 1, tmp, dst, src);
    }
    else {
        moveBlock(src, dst);
    }
}

void displaysolve(){
        if(!solution.empty())
                cout<<"The suggestion is to move the top disk from "<<solution.top().at(0)<<" to "
                        <<solution.top().at(1)<<endl;
}

void playermoveStack() {//source,destination,temporary
    if(isEmpty(0)&&isEmpty(1))//check if it's accomplished
        return;
    cout<<"Goal: Let every disk move to the last rod.\n"
    	<<"Do a move: "<<endl;
    int src=-1,dst=-1;
    cin>>src;
    cin>>dst;
    if(src==dst||src<0|| src>2||dst<0|| dst>2|| isEmpty(src)){//can't make the move due to typo
	show();
	displaysolve();//display the solution immediately after the graphs
        cerr<<"You can't make this move."<<endl;}
    else if (isValid(src,dst)){//can make the move
        push(dst, pop(src));
	//TVmove(dst,src);
	//we start to alter the solutions here
	if(src==int(solution.top().at(0))-48&&dst==int(solution.top().at(1))-48){
		solution.pop();
		show();
		displaysolve();
	}
	else {
		string sss;
                sss.append(to_string(dst));
                sss.append(to_string(src));
                solution.push(sss);
		show();
		displaysolve();
	}
	//we end the alternation here
    }
    else {//can't make the move due to rules
	show();
	displaysolve();//display the solution immediately after the graphs
        cerr<<"You can't make this move."<<endl;
    }
    playermoveStack();
}

void initStack() {
    for (int i = STACK_SIZE; i > 0; i--) {
        push(0, i);
    }
}

void solvearray(int n, string src, string dst, string tmp){//generate solution in queue of texts
        if(n==1){
                string sss;
                sss.append(src);
                sss.append(dst);
                solution1.push(sss);
                return;
        }
        else{
                solvearray(n-1,src,tmp,dst);
                string sss;
                sss.append(src);
                sss.append(dst);
                solution1.push(sss);
                solvearray(n-1,tmp,dst,src);}
}

void solveresult(){
int size = solution1.size();
        for(int i=0;i<size;i++){
                solution2.push(solution1.front());
                solution1.pop();}
        int size1 = solution2.size();
        for(int i=0;i<size1;i++){
                solution.push(solution2.top());
                solution2.pop();}
}

//TVmove();
//TVshow();

void initialize(){
    initStack();
    solvearray(STACK_SIZE,"0","2","1");
    solveresult();
    show();
    //TVshow();
    displaysolve();//display the solution immediately after the graphs
}

int main(){
    initialize();
    playermoveStack();
    cout<<"Congratulations!"<<endl;
return 0;}
