from tank import *
main();
